package com.student.webstudent;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "ViewAllServlet", value = "/ViewAllServlet")
public class ViewAllServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

       List<StudentDettails> view = StudentDAO.findALLStudents();
        request.setAttribute("view",view);

        request.getRequestDispatcher("viewAll.jsp").forward(request, response);


    }
}
