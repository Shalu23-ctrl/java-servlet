package com.student.webstudent;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {
    static Connection c = null;
    static PreparedStatement psmt = null;
    static ResultSet rs = null;


    public static void connectDatabase() throws ClassNotFoundException, SQLException {

        Class.forName("org.postgresql.Driver");
        c = DriverManager
                .getConnection("jdbc:postgresql://localhost:5432/Student",
                        "postgres", "whizzard@123");
    }
    public static void addStudentm (int id, String name, int age, String address){
        try {
            connectDatabase();

            psmt = c.prepareStatement("insert into \"Details\"\n" +
                    "values(?,?,?,?)");
            psmt.setInt(1, id);
            psmt.setString(2, name);
            psmt.setInt(3, age);
            psmt.setString(4, address);
            psmt.execute();

            psmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getMessage() + e.getClass().getName());
            System.exit(0);
        }
    }

    public static void removeStudentm ( int id){
        try{
            connectDatabase();
            psmt = c.prepareStatement("delete from \"Details\"\n" +
                    "where \"id\" =?");
            psmt.setInt(1, id);
            psmt.execute();

            psmt.close();
            c.close();

        } catch (Exception e ) {
            System.out.println(e.getMessage() + e.getClass().getName());
            System.exit(0);
        }
    }
    public static void UpdateStudentm(int id, String name, int age, String address){
        try{
            connectDatabase();
            psmt = c.prepareStatement("update \"Details\"\n" +
                    "set \"name\"= ?,\"age\"=?,\"address\"=?\n" +
                    "where \"id\"=?");
            psmt.setString(1, name);
            psmt.setInt(2, age);
            psmt.setString(3,address);
            psmt.setInt(4,id);
            psmt.execute();

            psmt.close();
            c.close();

        } catch (Exception e ) {
            System.out.println(e.getMessage() + e.getClass().getName());
            System.exit(0);
        }
    }
    public static List <StudentDettails> findALLStudents (){
        List<StudentDettails> s1 = new ArrayList();

        try{

            connectDatabase();
            psmt =c.prepareStatement("select * from \"Details\"");

            rs= psmt.executeQuery();
            int x = 0, z = 0;
            String y = null, s = null;

            while(rs.next()){
                x = rs.getInt(1);
                y = rs.getString(2);
                z = rs.getInt(3);
                s = rs.getString(4);

                StudentDettails sd = new StudentDettails();

                sd.setId(x);
                sd.setName(y);
                sd.setAge(z);
                sd.setAddress(s);

                s1.add(sd);
            }
        }catch(Exception e){
            System.err.println(e.getMessage()+e.getClass().getName());
            System.exit(0);
        }
        return s1;
}

    public static StudentDettails findStudentByID (int id) {

        StudentDettails sd = null;
        try {

            connectDatabase();
            psmt = c.prepareStatement("select * from \"Details\"\n" +
                    "where \"id\" = ?");

            psmt.setInt(1, id);
            rs = psmt.executeQuery();
            int x = 0, z = 0;
            String y = null, s = null;

            sd = new StudentDettails();
            if (rs.next()) {
                x = rs.getInt(1);
                y = rs.getString(2);
                z = rs.getInt(3);
                s = rs.getString(4);

                sd.setId(x);
                sd.setName(y);
                sd.setAge(z);
                sd.setAddress(s);
            }
        } catch (Exception e) {
            System.err.println(e.getMessage() + e.getClass().getName());
            System.exit(0);
        }
        return sd;
    }
}
