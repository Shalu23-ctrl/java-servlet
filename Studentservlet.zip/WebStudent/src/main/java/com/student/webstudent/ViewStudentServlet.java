package com.student.webstudent;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;


@WebServlet(name = "ViewStudentServlet", value = "/ViewStudentServlet")
public class ViewStudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String id = request.getParameter("id");
       StudentDettails details = StudentDAO.findStudentByID(Integer.parseInt(id));

        request.setAttribute("details",details);
        request.getRequestDispatcher("viewDetails.jsp").forward(request, response);

    }

}
