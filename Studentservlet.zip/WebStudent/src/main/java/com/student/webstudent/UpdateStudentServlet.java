package com.student.webstudent;

import com.student.webstudent.StudentDAO;
import com.student.webstudent.StudentDettails;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "UpdateStudentServlet",value = "/UpdateStudentServlet")
public class UpdateStudentServlet extends HttpServlet {
     @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        String name= request.getParameter("name");
        String age= request.getParameter("age");
        String address=request.getParameter("address");

        StudentDAO.UpdateStudentm(Integer.parseInt(id),name, Integer.parseInt(age),address);
        request.getRequestDispatcher("index.jsp").forward(request, response);

    }
}