package com.student.webstudent;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class StudentDettails {

    int id;
    String name;
    int age;
    String address;
}
