package com.student.webstudent;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AddStudentServlet", value = "/AddStudentServlet")
public class AddStudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String age = request.getParameter("age");
        String address = request.getParameter("address");

        StudentDAO.addStudentm(Integer.parseInt(id),name, Integer.parseInt(age),address);
        request.getRequestDispatcher("index.jsp").forward(request, response);

    }
}
