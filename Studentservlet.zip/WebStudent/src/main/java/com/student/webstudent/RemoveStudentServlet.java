package com.student.webstudent;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "RemoveStudentServlet", value = "/RemoveStudentServlet")
public class RemoveStudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String id = request.getParameter("id");
        StudentDAO.removeStudentm(Integer.parseInt(id));
        request.getRequestDispatcher("index.jsp").forward(request, response);


    }
}
